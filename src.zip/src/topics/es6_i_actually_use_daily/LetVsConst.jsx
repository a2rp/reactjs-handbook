import React from "react";

export default function LetVsConst() {
    const wrap = { maxWidth: 960, margin: "0 auto", padding: "1.25rem", lineHeight: 1.6 };

    return (
        <article style={wrap}>
            <h1>ES6+: let vs const (and the Temporal Dead Zone)</h1>

            <p>
                Quick, practical guide you’ll actually use daily. Prefer <code>const</code> by default,
                switch to <code>let</code> only when you need to reassign. Avoid <code>var</code>.
            </p>

            <h2>Definitions</h2>
            <ul>
                <li>
                    <code>let</code> → <strong>block-scoped</strong>, reassignable, not redeclarable in the same scope.
                </li>
                <li>
                    <code>const</code> → <strong>block-scoped binding</strong>. You can’t reassign the binding, but
                    array/object <em>contents</em> can mutate.
                </li>
                <li>
                    <strong>TDZ</strong> (Temporal Dead Zone) → between scope entry and the declaration line, a{" "}
                    <code>let/const</code> exists but isn’t initialized; accessing it throws{" "}
                    <code>ReferenceError</code>.
                </li>
            </ul>

            <h2>Key Points</h2>
            <ul>
                <li><strong>Scope:</strong> let/const → block; var → function.</li>
                <li><strong>Redeclare:</strong> let/const ❌ (same scope); var ✅.</li>
                <li><strong>Reassign:</strong> let ✅; const ❌ (but may mutate object/array contents).</li>
                <li><strong>Hoisting:</strong> all declarations hoist; let/const are in TDZ until declaration line.</li>
                <li><strong>Loops:</strong> let creates a fresh binding per iteration (great for closures).</li>
            </ul>

            <h2>Examples (copy–paste & run)</h2>

            <h3>A) Block scope &amp; redeclare vs reassign</h3>
            <pre>{`{
  let a = 1;
  a = 2;               // ✅ reassign allowed
  // let a = 3;        // ❌ SyntaxError: Identifier 'a' has already been declared

  const b = 10;
  // b = 11;           // ❌ TypeError: Assignment to constant variable.

  console.log(a, b);   // 2 10
}
// console.log(a, b);  // ❌ ReferenceError: a is not defined

let x = 5;
x = 6;                 // ✅ reassign ok
// let x = 7;          // ❌ cannot redeclare in the same scope

const y = { n: 1 };
// y = { n: 2 };       // ❌ cannot reassign binding
y.n = 2;               // ✅ mutate property
console.log(y);        // { n: 2 }`}</pre>

            <h3>B) TDZ in action</h3>
            <pre>{`try {
  console.log(counter); // ❌ TDZ → ReferenceError
  let counter = 1;
} catch (e) {
  console.log("TDZ example:", e.message);
}

try {
  console.log(rate);    // ❌ TDZ → ReferenceError
  const rate = 0.18;
} catch (e) {
  console.log("TDZ example:", e.message);
}`}</pre>

            <h3>C) TDZ with function parameters</h3>
            <pre>{`try {
  (function f(a = b, b = 1) { /* ... */ })(); // 'a' reads 'b' before it's initialized
} catch (e) {
  console.log("Param TDZ:", e.message); // ReferenceError
}`}</pre>

            <h3>D) Loops &amp; closures (why <code>let</code> shines)</h3>
            <pre>{`// VAR: one binding shared → all log 3
for (var i = 0; i < 3; i++) {
  setTimeout(() => console.log("var i:", i), 0);
}

// LET: new binding per iteration → 0,1,2
for (let j = 0; j < 3; j++) {
  setTimeout(() => console.log("let j:", j), 0);
}`}</pre>

            <h3>E) const with arrays/objects (mutate vs reassign)</h3>
            <pre>{`const arr = [1, 2, 3];
arr.push(4);           // ✅ mutate contents
// arr = [];           // ❌ reassign binding
console.log(arr);      // [1,2,3,4]

const user = Object.freeze({ id: 1, name: "Ash" });
// user.name = "New";  // ❌ (with freeze in strict mode)
console.log(user);`}</pre>

            <h3>F) Shadowing &amp; blocks</h3>
            <pre>{`let value = "outer";
{
  const value = "inner"; // shadowed in block scope
  console.log(value);    // "inner"
}
console.log(value);      // "outer"`}</pre>

            <h2>Takeaways</h2>
            <ol>
                <li>Declare before use → avoid TDZ.</li>
                <li><code>const</code> locks the reference, not the data (use <code>Object.freeze</code> for shallow immutability).</li>
                <li>Use <code>let</code> for counters/accumulators and when you truly need reassignment.</li>
                <li>In loops with async callbacks, prefer <code>let</code> to get per-iteration bindings.</li>
            </ol>

            <h2>Mini-Checklist</h2>
            <ul>
                <li>Default to <strong>const</strong>.</li>
                <li>Need to change value? → switch to <strong>let</strong>.</li>
                <li>No access before declaration (TDZ).</li>
                <li>Prefer block scope; avoid <code>var</code>.</li>
            </ul>
        </article>
    );
}
