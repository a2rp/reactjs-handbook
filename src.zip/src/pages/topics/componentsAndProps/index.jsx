import React from 'react'
import FunctionComponentAnatomy from './FunctionComponentAnatomy'
import DefaultFallbackProps from './DefaultFallbackProps'
import ChildrenProp from './ChildrenProp'
import CompositionOverInheritance from './CompositionOverInheritance'
import PropDrilling from './PropDrilling'
import PureVsStateful from './PureVsStateful'
import ReusableComponentAPIDesign from './ReusableComponentAPIDesign'

const ComponentsAndProps = () => {
    return (
        <div style={{ padding: "15px" }}>
            <h3>Components & Props</h3>
            <>
                <FunctionComponentAnatomy />
                <DefaultFallbackProps />
                <ChildrenProp />
                <CompositionOverInheritance />
                <PropDrilling />
                <PureVsStateful />
                <ReusableComponentAPIDesign />
            </>
        </div>
    )
}

export default ComponentsAndProps