import JSXSyntaxRules from './JSXSyntaxRules'
import HTMLvsJSX from './HTMLvsJSX'
import InlineStyles from './InlineStyles'
import Fragments from './Fragments'
import CommentsInJSX from './CommentsInJSX'
import ExpressionsVsStatements from './ExpressionsVsStatements'
import ConditionalAnd from './ConditionalAnd'
import ConditionalTernary from './ConditionalTernary'
import EarlyReturn from './EarlyReturn'
import RenderingLists from './RenderingLists'
import KeysStableIdentity from './KeysStableIdentity'
import DangerousHTML from './DangerousHTML'

const JsxRulesAndPatterns = () => {
    return (
        <div style={{ padding: "15px" }}>
            <h3>JSX: Rules and Patterns</h3>
            <>
                <JSXSyntaxRules />
                <HTMLvsJSX />
                <InlineStyles />
                <Fragments />
                <CommentsInJSX />
                <ExpressionsVsStatements />
                <ConditionalAnd />
                <ConditionalTernary />
                <EarlyReturn />
                <RenderingLists />
                <KeysStableIdentity />
                <DangerousHTML />
            </>
        </div>
    )
}

export default JsxRulesAndPatterns