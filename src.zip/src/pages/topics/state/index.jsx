import React from 'react'
import AntiPatterns from './AntiPatterns'
import BatchingStateUpdates from './BatchingStateUpdates'
import DerivedStateVsCompute from './DerivedStateVsCompute'
import ArraysInState from './ArraysInState'
import ObjectsInState from './ObjectsInState'
import MultipleStateVariables from './MultipleStateVariables'
import InitialStateFunction from './InitialStateFunction'
import FunctionalUpdates from './FunctionalUpdates'
import UseStateBasics from './UseStateBasics'

const State = () => {
    return (
        <div style={{ padding: "15px" }}>
            <h3>State (useState) - fundamentals</h3>
            <>
                <UseStateBasics />
                <FunctionalUpdates />
                <InitialStateFunction />
                <MultipleStateVariables />
                <ObjectsInState />
                <ArraysInState />
                <DerivedStateVsCompute />
                <BatchingStateUpdates />
                <AntiPatterns />
            </>
        </div>
    )
}

export default State

