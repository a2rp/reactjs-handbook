import ReactDefinition from './ReactDefinition'
import ViteInstall from './ViteInstall'
import ProjectTree from './ProjectTree'
import EditorSetup from './EditorSetup'
import EnvFiles from './EnvFiles'
import ImportExportBasics from './ImportExportBasics'

const SetupAndLocalDev = () => {
    return (
        <div style={{ padding: "15px" }}>
            <h3>Setup & Local Dev</h3>
            <>
                <ReactDefinition />
                <ViteInstall />
                <ProjectTree />
                <EditorSetup />
                <EnvFiles />
                <ImportExportBasics />
            </>
        </div>
    )
}

export default SetupAndLocalDev