import LetVsConst from "./LetVsConst";
import ArrowFunctions from "./ArrowFunctions";
import Destructuring from "./Destructuring";
import RestAndSpread from "./RestAndSpread";
import TemplateLiterals from "./TemplateLiterals";
import DefaultParameters from "./DefaultParameters";
import OptionalChaining from "./OptionalChaining";
import NullishCoalescing from "./NullishCoalescing";
import MapFilterReduce from "./MapFilterReduce";
import FindSomeEvery from "./FindSomeEvery";
import SortNoMutate from "./SortNoMutate";
import FlatAndFlatMap from "./FlatAndFlatMap";
import ObjectUtilities from "./ObjectUtilities";
import SetsAndMaps from "./SetsAndMaps";
import PromisesAsyncAwait from "./PromisesAsyncAwait";
import FetchBasicsJSON from "./FetchBasicsJSON";
import Timers from "./Timers";

const Es6IActuallyUseDaily = () => {
    return (
        <div style={{ padding: "15px" }}>
            <h3>ES6+ I actually use daily</h3>
            <>
                <LetVsConst />
                <ArrowFunctions />
                <Destructuring />
                <RestAndSpread />
                <TemplateLiterals />
                <DefaultParameters />
                <OptionalChaining />
                <NullishCoalescing />
                <MapFilterReduce />
                <FindSomeEvery />
                <SortNoMutate />
                <FlatAndFlatMap />
                <ObjectUtilities />
                <SetsAndMaps />
                <PromisesAsyncAwait />
                <FetchBasicsJSON />
                <Timers />
            </>
        </div>
    )
}

export default Es6IActuallyUseDaily